"use client"

import { useState } from "react"
import { LandingPage } from "@/components/landing-page"
import { MainApp } from "@/components/main-app"

export default function LiminalApp() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  if (!isAuthenticated) {
    return (
      <LandingPage
        onAuthenticate={() => {
          setIsAuthenticated(true)
        }}
      />
    )
  }

  return <MainApp />
}
