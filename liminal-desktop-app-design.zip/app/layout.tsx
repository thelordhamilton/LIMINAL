import type React from "react"
import type { Metadata } from "next"
import { Inter, Orbitron, Happy_Monkey } from 'next/font/google'
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const orbitron = Orbitron({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-orbitron",
})

const happyMonkey = Happy_Monkey({
  weight: "400",
  subsets: ["latin"],
  display: "swap",
  variable: "--font-happy-monkey",
})

export const metadata: Metadata = {
  title: "LIMINAL - Media Player",
  description: "Advanced media player with glass morphism design",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${orbitron.variable} ${happyMonkey.variable}`}>
      <body>{children}</body>
    </html>
  )
}
