# Liminal desktop app design

*Automatically synced with your [v0.app](https://v0.app) deployments*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/throwawaaaygarbage-4802s-projects/v0-liminal-desktop-app-design)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.app-black?style=for-the-badge)](https://v0.app/chat/projects/70Sx1fKKPg4)

## Overview

This repository will stay in sync with your deployed chats on [v0.app](https://v0.app).
Any changes you make to your deployed app will be automatically pushed to this repository from [v0.app](https://v0.app).

## Deployment

Your project is live at:

**[https://vercel.com/throwawaaaygarbage-4802s-projects/v0-liminal-desktop-app-design](https://vercel.com/throwawaaaygarbage-4802s-projects/v0-liminal-desktop-app-design)**

## Build your app

Continue building your app on:

**[https://v0.app/chat/projects/70Sx1fKKPg4](https://v0.app/chat/projects/70Sx1fKKPg4)**

## How It Works

1. Create and modify your project using [v0.app](https://v0.app)
2. Deploy your chats from the v0 interface
3. Changes are automatically pushed to this repository
4. Vercel deploys the latest version from this repository
