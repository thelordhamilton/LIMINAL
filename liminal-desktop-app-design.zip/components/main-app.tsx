"use client"

import { useState } from "react"
import { Dashboard } from "./dashboard"
import { PicturesPage } from "./pictures-page"
import { VideosPage } from "./videos-page"
import { AudioPage } from "./audio-page"
import { FilesPage } from "./files-page"

type Page = "dashboard" | "pictures" | "videos" | "audio" | "files"

export function MainApp() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState<Page>("dashboard")
  const [uploadedMedia, setUploadedMedia] = useState<{
    pictures: File[]
    videos: File[]
    audio: File[]
    files: File[]
  }>({
    pictures: [],
    videos: [],
    audio: [],
    files: [],
  })

  const navigateTo = (page: Page) => {
    setCurrentPage(page)
    setMenuOpen(false)
  }

  const handleMediaUpload = (type: Page, files: File[]) => {
    if (type === "pictures" || type === "videos" || type === "audio" || type === "files") {
      setUploadedMedia((prev) => ({
        ...prev,
        [type]: [...prev[type], ...files],
      }))
    }
  }

  return (
  <div className="min-h-screen main-app-container overflow-visible">  
    <header className="glass-panel-realistic backdrop-blur-md px-4 h-16 m-3 depth-layer-2 relative overflow-visible"> 
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="glass-button-etched p-2 hover:scale-105 transition-transform z-10 absolute left-4"
          aria-label="Toggle menu"
        >
          <div className="w-5 h-4 flex flex-col justify-between">
            <span className="w-full h-0.5 bg-white/90 transition-all shadow-sm"></span>
            <span className="w-full h-0.5 bg-white/90 transition-all shadow-sm"></span>
            <span className="w-full h-0.5 bg-white/90 transition-all shadow-sm"></span>
          </div>
        </button>

        <div className="absolute left-0 w-full h-48 flex justify-center items-end" style={{ top: '100px' }}>
          <img 
            src="/images/design-mode/Whisk_yqdmxqgm0qmz4mdntgtz1gtlzctm00cnijtztgd-removebg-preview.png" 
            alt="LIMINAL" 
            className="h-full w-auto object-contain"
            style={{ filter: 'drop-shadow(0 0 5px white)' }}
          />
        </div>
      </header>

      <div
        className={`fixed top-0 left-0 h-full w-16 z-50 transition-transform duration-300 ease-in-out ${
          menuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="glass-panel-realistic h-full flex flex-col items-center py-4 gap-3 backdrop-blur-md border-r-2 border-r-white/20">
          <button
            onClick={() => setMenuOpen(false)}
            className="glass-button-etched p-2 hover:scale-110 transition-transform mb-2"
            aria-label="Close menu"
          >
            <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </button>

          <nav className="flex flex-col gap-2 items-center">
            <button 
              className={`glass-button-etched p-2.5 hover:scale-110 transition-all ${currentPage === 'dashboard' ? 'border-white/50 bg-white/5' : ''}`}
              onClick={() => navigateTo('dashboard')}
              aria-label="Dashboard"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </button>

            <button 
              className={`glass-button-etched p-2.5 hover:scale-110 transition-all ${currentPage === 'pictures' ? 'border-white/50 bg-white/5' : ''}`}
              onClick={() => navigateTo('pictures')}
              aria-label="Pictures"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586A2 2 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </button>

            <button 
              className={`glass-button-etched p-2.5 hover:scale-110 transition-all ${currentPage === 'videos' ? 'border-white/50 bg-white/5' : ''}`}
              onClick={() => navigateTo('videos')}
              aria-label="Videos"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </button>

            <button 
              className={`glass-button-etched p-2.5 hover:scale-110 transition-all ${currentPage === 'audio' ? 'border-white/50 bg-white/5' : ''}`}
              onClick={() => navigateTo('audio')}
              aria-label="Audio"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l4.586-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
            </button>

            <button 
              className={`glass-button-etched p-2.5 hover:scale-110 transition-all ${currentPage === 'files' ? 'border-white/50 bg-white/5' : ''}`}
              onClick={() => navigateTo('files')}
              aria-label="Files"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
            </button>
          </nav>
        </div>
      </div>

      {/* Overlay when menu is open */}
      {menuOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
          onClick={() => setMenuOpen(false)}
        ></div>
      )}

      <main className="mt-4">
        {currentPage === "dashboard" && <Dashboard onNavigate={(page) => navigateTo(page as Page)} onUpload={handleMediaUpload} />}
        {currentPage === "pictures" && <PicturesPage photos={uploadedMedia.pictures} />}
        {currentPage === "videos" && <VideosPage videos={uploadedMedia.videos} />}
        {currentPage === "audio" && <AudioPage audioFiles={uploadedMedia.audio} />}
        {currentPage === "files" && <FilesPage files={uploadedMedia.files} />}
      </main>

      <footer className="text-center py-4 mt-8">
        <p className="text-white/50 text-xs font-medium tracking-wide">
          LIMINAL is created by Lord Liminal LLC™ - © All Rights Reserved
        </p>
      </footer>
    </div>
  )
}
