"use client"

import { useState } from "react"
import Image from "next/image"

interface Photo {
  id: string
  url: string
  file?: File
}

export function PicturesPage({ photos: uploadedPhotos = [] }: { photos?: File[] }) {
  const [photos, setPhotos] = useState<Photo[]>(
    uploadedPhotos.map((file, i) => ({
      id: `photo-${i}`,
      url: URL.createObjectURL(file),
      file,
    }))
  )
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)

  const handlePhotoDoubleClick = (photo: Photo) => {
    setSelectedPhoto(photo)
  }

  const handleNext = () => {
    if (!selectedPhoto) return
    const currentIndex = photos.findIndex((p) => p.id === selectedPhoto.id)
    const nextIndex = (currentIndex + 1) % photos.length
    setSelectedPhoto(photos[nextIndex])
  }

  const handlePrevious = () => {
    if (!selectedPhoto) return
    const currentIndex = photos.findIndex((p) => p.id === selectedPhoto.id)
    const previousIndex = (currentIndex - 1 + photos.length) % photos.length
    setSelectedPhoto(photos[previousIndex])
  }

  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h2 className="text-etched text-2xl mb-4">Pictures</h2>
      
      {photos.length > 0 ? (
        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-9 gap-2">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="convex-media-frame aspect-square overflow-hidden hover:scale-105 transition-all duration-300 cursor-pointer"
              onDoubleClick={() => handlePhotoDoubleClick(photo)}
            >
              <div className="relative w-full h-full">
                <Image
                  src={photo.url || "/placeholder.svg"}
                  alt={`Photo ${photo.id}`}
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-white/40 mt-20">
          <p className="text-etched text-xl">No pictures yet</p>
          <p className="text-white/30 text-sm mt-2">Upload photos from the dashboard</p>
        </div>
      )}

      {selectedPhoto && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4" onClick={() => setSelectedPhoto(null)}>
          <div className="glass-panel-realistic p-4 max-w-6xl max-h-[90vh] relative" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-2 right-2 glass-button-etched p-2 z-10 hover:scale-110 transition-transform"
            >
              <svg className="w-5 h-5 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="relative w-full h-[70vh]">
              <Image
                src={selectedPhoto.url || "/placeholder.svg"}
                alt="Selected photo"
                fill
                className="object-contain"
              />
            </div>

            <div className="flex items-center justify-center gap-4 mt-4">
              <button
                onClick={handlePrevious}
                className="glass-button-etched p-3 rounded-full hover:scale-110 transition-transform"
              >
                <svg className="w-6 h-6 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>

              <button
                onClick={handleNext}
                className="glass-button-etched p-3 rounded-full hover:scale-110 transition-transform"
              >
                <svg className="w-6 h-6 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
