"use client"

import { useState } from "react"

export function AudioPage() {
  const [tracks] = useState(
    Array.from({ length: 12 }, (_, i) => ({
      id: i + 1,
      title: `Track ${i + 1}`,
      artist: "Artist Name",
      duration: "3:45",
    }))
  )

  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h2 className="text-etched text-2xl mb-4">Audio</h2>
      
      <div className="glass-panel-realistic p-4 max-w-4xl mx-auto">
        <div className="space-y-1.5">
          {tracks.map((track) => (
            <div
              key={track.id}
              className="glass-button-etched p-3 flex items-center justify-between hover:scale-[1.01] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-white/80" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
                <div>
                  <p className="text-white/90 font-medium text-sm">{track.title}</p>
                  <p className="text-white/50 text-xs">{track.artist}</p>
                </div>
              </div>
              <span className="text-white/60 text-xs">{track.duration}</span>
            </div>
          ))}
        </div>
      </div>
      
      {tracks.length === 0 && (
        <div className="text-center text-white/40 mt-20">
          <p className="text-etched text-xl">No audio files yet</p>
        </div>
      )}
    </div>
  )
}
