"use client"

import { useState } from "react"

export function FilesPage() {
  const [files] = useState(
    Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      name: `Document_${i + 1}.pdf`,
      size: "2.4 MB",
      date: "2025-01-15",
    }))
  )

  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h2 className="text-etched text-2xl mb-4">Files</h2>
      
      <div className="glass-panel-realistic p-4 max-w-5xl mx-auto">
        <div className="space-y-1.5">
          {files.map((file) => (
            <div
              key={file.id}
              className="glass-button-etched p-3 flex items-center justify-between hover:scale-[1.01] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                <div>
                  <p className="text-white/90 font-medium text-sm">{file.name}</p>
                  <p className="text-white/50 text-xs">{file.date}</p>
                </div>
              </div>
              <span className="text-white/60 text-xs">{file.size}</span>
            </div>
          ))}
        </div>
      </div>
      
      {files.length === 0 && (
        <div className="text-center text-white/40 mt-20">
          <p className="text-etched text-xl">No files yet</p>
        </div>
      )}
    </div>
  )
}
