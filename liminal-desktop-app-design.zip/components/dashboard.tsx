"use client"

import { useState } from "react"

type UploadType = "pictures" | "videos" | "audio" | "files"

interface UploadPanelProps {
  type: UploadType
  icon: React.ReactNode
  label: string
  onUpload: (type: UploadType, files: FileList) => void
}

function UploadPanel({ type, icon, label, onUpload }: UploadPanelProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    if (e.dataTransfer.files) {
      onUpload(type, e.dataTransfer.files)
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      onUpload(type, e.target.files)
    }
  }

  return (
    <div
      className={`upload-panel-glass p-8 flex flex-col items-center justify-center gap-4 min-h-[200px] cursor-pointer transition-all ${
        isDragging ? "border-solid scale-105" : ""
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => document.getElementById(`file-input-${type}`)?.click()}
    >
      <div className="text-white/70 transform scale-125">{icon}</div>
      <span className="text-etched text-xl">{label}</span>
      <p className="text-white/40 text-sm text-center">Drop files here or click to browse</p>
      <input
        id={`file-input-${type}`}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileInput}
      />
    </div>
  )
}

export function Dashboard({ onNavigate, onUpload }: { onNavigate: (page: string) => void; onUpload: (type: any, files: File[]) => void }) {
  const handleUpload = async (type: UploadType, files: FileList) => {
    const filesArray = Array.from(files)
    console.log(`[v0] Uploading ${filesArray.length} files to ${type}`)
    
    onUpload(type, filesArray)
    
    setTimeout(() => {
      onNavigate(type)
    }, 500)
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h2 className="text-etched text-4xl mb-8 text-center">Upload Media</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <UploadPanel
          type="pictures"
          label="Pictures"
          icon={
            <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          }
          onUpload={handleUpload}
        />

        <UploadPanel
          type="videos"
          label="Videos"
          icon={
            <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          }
          onUpload={handleUpload}
        />

        <UploadPanel
          type="audio"
          label="Audio"
          icon={
            <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
            </svg>
          }
          onUpload={handleUpload}
        />

        <UploadPanel
          type="files"
          label="Files"
          icon={
            <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0112.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
          }
          onUpload={handleUpload}
        />
      </div>

      <div className="mt-12">
        <h3 className="text-etched text-2xl mb-6 text-center">Secure Transfer</h3>
        <div className="glass-panel-realistic p-8 max-w-2xl mx-auto">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-center">
            <button className="glass-button-etched px-6 py-4 flex items-center gap-3 hover:scale-105 transition-transform">
              <svg className="w-6 h-6 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <span className="text-etched">Send via Messenger</span>
            </button>

            <button className="glass-button-etched px-6 py-4 flex items-center gap-3 hover:scale-105 transition-transform">
              <svg className="w-6 h-6 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
              </svg>
              <span className="text-etched">Generate QR Code</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
