"use client"

import { useState, useRef } from "react"
import Image from "next/image"

interface Video {
  id: string
  url: string
  thumbnail: string
  title: string
  file?: File
}

export function VideosPage({ videos: uploadedVideos = [] }: { videos?: File[] }) {
  const [videos, setVideos] = useState<Video[]>(
    uploadedVideos.map((file, i) => ({
      id: `video-${i}`,
      url: URL.createObjectURL(file),
      thumbnail: URL.createObjectURL(file),
      title: file.name,
      file,
    }))
  )

  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  const handlePlayPause = () => {
    if (!videoRef.current) return
    
    if (isPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }

  const handleVideoSelect = (video: Video) => {
    setSelectedVideo(video)
    setIsPlaying(false)
  }

  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h2 className="text-etched text-2xl mb-4">Videos</h2>
      
      <div className="glass-panel-realistic p-4 mb-6 max-w-5xl mx-auto">
        <div className="aspect-video bg-black/50 rounded-lg overflow-hidden relative convex-media-frame">
          {selectedVideo ? (
            <video
              ref={videoRef}
              src={selectedVideo.url}
              className="w-full h-full object-contain"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-white/40 text-sm">Select a video to play</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-center gap-3 mt-3">
          <button 
            className="glass-button-etched p-2 rounded-full hover:scale-110 transition-transform"
            onClick={() => {
              const currentIndex = videos.findIndex((v) => v.id === selectedVideo?.id)
              if (currentIndex > 0) setSelectedVideo(videos[currentIndex - 1])
            }}
            disabled={!selectedVideo}
          >
            <svg className="w-5 h-5 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <button 
            className="glass-button-etched p-3 rounded-full hover:scale-110 transition-transform"
            onClick={handlePlayPause}
            disabled={!selectedVideo}
          >
            {isPlaying ? (
              <svg className="w-6 h-6 text-white/90" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
              </svg>
            ) : (
              <svg className="w-6 h-6 text-white/90" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>
          
          <button 
            className="glass-button-etched p-2 rounded-full hover:scale-110 transition-transform"
            onClick={() => {
              const currentIndex = videos.findIndex((v) => v.id === selectedVideo?.id)
              if (currentIndex < videos.length - 1) setSelectedVideo(videos[currentIndex + 1])
            }}
            disabled={!selectedVideo}
          >
            <svg className="w-5 h-5 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {videos.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
          {videos.map((video) => (
            <div
              key={video.id}
              className="convex-media-frame aspect-video overflow-hidden hover:scale-105 transition-all duration-300 cursor-pointer"
              onClick={() => handleVideoSelect(video)}
            >
              <div className="relative w-full h-full">
                <video src={video.url} className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/10 transition-colors">
                  <svg className="w-8 h-8 text-white/80" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-white/40 mt-20">
          <p className="text-etched text-xl">No videos yet</p>
          <p className="text-white/30 text-sm mt-2">Upload videos from the dashboard</p>
        </div>
      )}
    </div>
  )
}
